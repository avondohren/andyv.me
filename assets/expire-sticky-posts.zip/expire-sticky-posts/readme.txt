=== Expire Sticky Posts ===
Plugin URI: http://andyv.me/assets/expire-sticky-posts.zip
Author URI: http://andyv.me
Contributors: avondohren, mordauk, rzen, pippinsplugins
Tags: expiration, posts, expire, sticky
Requires at least: 3.6
Tested up to: 4.0
Stable Tag: 1.0

A simple plugin that allows you to set an expiration date on posts. Once a post is expired, it will no longer be sticky.

== Description ==

A simple plugin that allows you to set an expiration date on posts. Once a post is expired, it will no longer be sticky.

Have you found a bug or have a suggestion or improvement you'd like to submit? This plugin is available on [Github](https://github.com/avondohren/Expire-Sticky-Posts) and pull requests are welcome!


== Screenshots ==

1. Metabox added to each post / custom post type
2. Metabox with calendar showing

== Installation ==

1. Activate the plugin
2. Add an expiration date to any post item that you wish to expire at a certain point in time

== Changelog ==

= 1.0 =

* First release!
